//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PC_LDR.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_PC_LDR_FORM                 101
#define IDR_MAINFRAME                   128
#define IDR_PC_LDRTYPE                  129
#define IDD_DATAIN_DLG                  130
#define IDR_LIST_MENU                   131
#define IDB_LAMP                        136
#define IDC_LED_CLOSE                   422
#define IDC_LED_OPEN                    423
#define IDC_LED_NUDGE                   424
#define IDC_LED_HCL                     425
#define IDC_VAR_LIST                    1005
#define IDC_DATA                        1006
#define IDC_COMM_EN                     1007
#define IDC_DATA2                       1007
#define IDC_DISP                        1008
#define IDC_VAR_LIST_IN                 1009
#define IDC_SET_VARI                    1010
#define IDC_MAPFILE_NAME                1011
#define IDC_GROUP                       1014
#define IDC_IDX                         1015
#define IDC_DATA_SET                    1017
#define IDC_FWD_RUN                     1018
#define IDC_STOP                        1019
#define IDC_PARA_SAVE                   1020
#define IDC_REV_RUN                     1021
#define IDC_UNIT                        1022
#define IDC_PARA_INIT                   1022
#define IDC_SET                         1023
#define IDC_DO2                         1024
#define IDC_OutFreq                     1025
#define IDC_RefFreq                     1026
#define IDC_OutCur                      1027
#define IDC_OutV                        1028
#define IDC_DCV                         1029
#define IDC_TRIP                        1030
#define IDC_VER                         1031
#define IDC_COMM                        1032
#define IDC_PROGRESS                    1033
#define IDC_PORT_IN                     1034
#define IDC_DO3                         1035
#define IDC_DO4                         1036
#define IDC_DO5                         1037
#define IDC_CLEAR                       1038
#define IDC_DO12                        1039
#define IDC_DO13                        1040
#define IDC_DO15                        1041
#define IDC_CLEAR2                      1042
#define IDC_DO_READY                    1043
#define IDM_COM1                        32771
#define IDM_COM2                        32772
#define IMD_UP                          32773
#define IDM_DOWN                        32774
#define IDM_DEL                         32775
#define IDM_SET_DATA                    32777
#define IDM_SET_INT                     32778
#define IDM_SET_UINT                    32779
#define IDM_SET_BIN                     32780
#define IDM_SET_HEX                     32781
#define IDM_DEL_ALL                     32782
#define ID_RELOAD                       32783
#define ID_FILE_WRITE                   32784
#define ID_INDICATOR_STATUS             59142

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32785
#define _APS_NEXT_CONTROL_VALUE         1034
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
